/*
 * ClosedLab01a.java
 * A simple program to display a greeting to the screen
 * Also to get familiar with the Eclipse IDE
 * 
 * @author Harshil S. Patel
 * @version 20180110
 */


package osu.cse1223;

public class ClosedLab01a {

	public static void main(String[] args) {
		System.out.println("Hello World!");
	}

}
