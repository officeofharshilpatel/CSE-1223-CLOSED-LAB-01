/*
 * ClosedLab01c.java
 * The programs ask the user for their name and a whole number, which is entered by the user. Then the program outputs: a greeting with the user's name, value for user's entered whole number and number, and values for the user's number squared and cubed.
 *
 * This program did what I initially thought.
 * 
 * 
 * 
 *  @author Harshil S. Patel
 *  @version 20180110
 */

package osu.cse1223;

import java.util.Scanner;

public class ClosedLab01c {

	public static void main(String[] args) {
		
		Scanner keyboard = new Scanner(System.in);
		System.out.print("Enter your name: ");
		String myName = keyboard.nextLine();
		System.out.print("Enter a whole number: ");
		int number = keyboard.nextInt();
		System.out.println("Hello " + myName);
		System.out.println("Your number is: " + number);
		System.out.println("The number squared is: " + (number * number));
		int cubed = number*number*number;
		System.out.println("The number cubed is: " + cubed);

	}

}
